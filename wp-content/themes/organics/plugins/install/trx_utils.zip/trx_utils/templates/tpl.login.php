<?php
/**
 * The template to display login link and popup
 *
 * @package WordPress
 * @subpackage ThemeREX Utilities
 * @since v3.0
 */

// Display link
$args = get_query_var('trx_utils_args_login');

if( is_array($args['show_attr']) && in_array('link', $args['show_attr']) ) {
	?><a href="#popup_login" class="popup_link popup_login_link icon-user" title="<?php echo esc_attr($args['link_title']); ?>"><?php echo esc_html($args['link_text']); ?></a><?php
}

if( is_array($args['show_attr']) && in_array('popup', $args['show_attr']) ) {

// Prepare popup
$social_login = do_shortcode(apply_filters('trx_utils_filter_social_login', ''));
?>
<div id="popup_login" class="popup_wrap popup_login bg_tint_light<?php if (empty($social_login)) echo ' popup_half'; ?>">
	<a href="#" class="popup_close"></a>
	<div class="form_wrap">
		<div<?php if (!empty($social_login)) echo ' class="form_left"'; ?>>
			<form action="<?php echo wp_login_url(); ?>" method="post" name="login_form" class="popup_form login_form">
				<input type="hidden" name="redirect_to" value="<?php echo esc_url(home_url('/')); ?>">
				<div class="popup_form_field login_field iconed_field icon-user"><input type="text" id="log<?php echo esc_attr($args['inc_id']); ?>" name="log" value="" placeholder="<?php esc_attr_e('Login or Email', 'trx_utils'); ?>" autocomplete="username"></div>
				<div class="popup_form_field password_field iconed_field icon-lock"><input type="password" id="password<?php echo esc_attr($args['inc_id']); ?>" name="pwd" value="" placeholder="<?php esc_attr_e('Password', 'trx_utils'); ?>" autocomplete="current-password"></div>
				<div class="popup_form_field remember_field">
					<a href="<?php echo esc_url(wp_lostpassword_url(get_permalink())); ?>" class="forgot_password"><?php esc_html_e('Forgot password?', 'trx_utils'); ?></a>
					<input type="checkbox" value="forever" id="rememberme<?php echo esc_attr($args['inc_id']); ?>" name="rememberme">
					<label for="rememberme"><?php esc_html_e('Remember me', 'trx_utils'); ?></label>
				</div>
				<div class="popup_form_field submit_field"><input type="submit" class="submit_button" value="<?php esc_attr_e('Login', 'trx_utils'); ?>"></div>
			</form>
		</div>
		<?php if (!empty($social_login))  { ?>
			<div class="form_right">
				<div class="login_socials_title"><?php esc_html_e('You can login using your social profile', 'trx_utils'); ?></div>
				<div class="login_socials_list">
					<?php trx_utils_show_layout($social_login); ?>
				</div>
			</div>
		<?php } ?>
	</div>	<!-- /.login_wrap -->
</div>		<!-- /.popup_login -->
<?php } //End if (is_array($args['show_attr']) && in_array('link', $args['show_attr']))  ?>